.class public final Landroidx/appcompat/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static action_bar:I = 0x7f0a0035

.field public static action_bar_activity_content:I = 0x7f0a0036

.field public static action_bar_container:I = 0x7f0a0037

.field public static action_bar_root:I = 0x7f0a0038

.field public static action_bar_spinner:I = 0x7f0a0039

.field public static action_bar_subtitle:I = 0x7f0a003a

.field public static action_bar_title:I = 0x7f0a003b

.field public static action_context_bar:I = 0x7f0a003d

.field public static action_menu_divider:I = 0x7f0a0042

.field public static action_menu_presenter:I = 0x7f0a0043

.field public static action_mode_bar:I = 0x7f0a0044

.field public static action_mode_bar_stub:I = 0x7f0a0045

.field public static action_mode_close_button:I = 0x7f0a0046

.field public static activity_chooser_view_content:I = 0x7f0a004a

.field public static add:I = 0x7f0a004b

.field public static alertTitle:I = 0x7f0a0051

.field public static buttonPanel:I = 0x7f0a0095

.field public static checkbox:I = 0x7f0a00b0

.field public static checked:I = 0x7f0a00b1

.field public static content:I = 0x7f0a00ce

.field public static contentPanel:I = 0x7f0a00cf

.field public static custom:I = 0x7f0a00de

.field public static customPanel:I = 0x7f0a00df

.field public static decor_content_parent:I = 0x7f0a00ef

.field public static default_activity_button:I = 0x7f0a00f0

.field public static edit_query:I = 0x7f0a0134

.field public static expand_activities_button:I = 0x7f0a0140

.field public static expanded_menu:I = 0x7f0a0141

.field public static group_divider:I = 0x7f0a016a

.field public static home:I = 0x7f0a0174

.field public static icon:I = 0x7f0a017b

.field public static image:I = 0x7f0a0181

.field public static listMode:I = 0x7f0a01a7

.field public static list_item:I = 0x7f0a01a9

.field public static message:I = 0x7f0a01d4

.field public static multiply:I = 0x7f0a01fa

.field public static none:I = 0x7f0a0212

.field public static normal:I = 0x7f0a0213

.field public static off:I = 0x7f0a0218

.field public static on:I = 0x7f0a021a

.field public static parentPanel:I = 0x7f0a0253

.field public static progress_circular:I = 0x7f0a02a9

.field public static progress_horizontal:I = 0x7f0a02aa

.field public static radio:I = 0x7f0a02ae

.field public static screen:I = 0x7f0a02c8

.field public static scrollIndicatorDown:I = 0x7f0a02d4

.field public static scrollIndicatorUp:I = 0x7f0a02d5

.field public static scrollView:I = 0x7f0a02d6

.field public static search_badge:I = 0x7f0a02d8

.field public static search_bar:I = 0x7f0a02d9

.field public static search_button:I = 0x7f0a02da

.field public static search_close_btn:I = 0x7f0a02db

.field public static search_edit_frame:I = 0x7f0a02dc

.field public static search_go_btn:I = 0x7f0a02dd

.field public static search_mag_icon:I = 0x7f0a02de

.field public static search_plate:I = 0x7f0a02df

.field public static search_src_text:I = 0x7f0a02e0

.field public static search_voice_btn:I = 0x7f0a02e1

.field public static select_dialog_listview:I = 0x7f0a02f3

.field public static shortcut:I = 0x7f0a0312

.field public static spacer:I = 0x7f0a0326

.field public static split_action_bar:I = 0x7f0a032e

.field public static src_atop:I = 0x7f0a0333

.field public static src_in:I = 0x7f0a0334

.field public static src_over:I = 0x7f0a0335

.field public static submenuarrow:I = 0x7f0a0367

.field public static submit_area:I = 0x7f0a0368

.field public static tabMode:I = 0x7f0a0373

.field public static textSpacerNoButtons:I = 0x7f0a038f

.field public static textSpacerNoTitle:I = 0x7f0a0390

.field public static title:I = 0x7f0a03a1

.field public static titleDividerNoCustom:I = 0x7f0a03a2

.field public static title_template:I = 0x7f0a03bd

.field public static topPanel:I = 0x7f0a03c2

.field public static unchecked:I = 0x7f0a03d4

.field public static uniform:I = 0x7f0a03d5

.field public static up:I = 0x7f0a03d8

.field public static wrap_content:I = 0x7f0a0408


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
