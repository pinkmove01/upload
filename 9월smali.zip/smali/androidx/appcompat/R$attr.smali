.class public final Landroidx/appcompat/R$attr;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "attr"
.end annotation


# static fields
.field public static actionBarDivider:I = 0x7f040002

.field public static actionBarItemBackground:I = 0x7f040003

.field public static actionBarPopupTheme:I = 0x7f040004

.field public static actionBarSize:I = 0x7f040005

.field public static actionBarSplitStyle:I = 0x7f040006

.field public static actionBarStyle:I = 0x7f040007

.field public static actionBarTabBarStyle:I = 0x7f040008

.field public static actionBarTabStyle:I = 0x7f040009

.field public static actionBarTabTextStyle:I = 0x7f04000a

.field public static actionBarTheme:I = 0x7f04000b

.field public static actionBarWidgetTheme:I = 0x7f04000c

.field public static actionButtonStyle:I = 0x7f04000d

.field public static actionDropDownStyle:I = 0x7f04000e

.field public static actionLayout:I = 0x7f04000f

.field public static actionMenuTextAppearance:I = 0x7f040010

.field public static actionMenuTextColor:I = 0x7f040011

.field public static actionModeBackground:I = 0x7f040012

.field public static actionModeCloseButtonStyle:I = 0x7f040013

.field public static actionModeCloseContentDescription:I = 0x7f040014

.field public static actionModeCloseDrawable:I = 0x7f040015

.field public static actionModeCopyDrawable:I = 0x7f040016

.field public static actionModeCutDrawable:I = 0x7f040017

.field public static actionModeFindDrawable:I = 0x7f040018

.field public static actionModePasteDrawable:I = 0x7f040019

.field public static actionModePopupWindowStyle:I = 0x7f04001a

.field public static actionModeSelectAllDrawable:I = 0x7f04001b

.field public static actionModeShareDrawable:I = 0x7f04001c

.field public static actionModeSplitBackground:I = 0x7f04001d

.field public static actionModeStyle:I = 0x7f04001e

.field public static actionModeTheme:I = 0x7f04001f

.field public static actionModeWebSearchDrawable:I = 0x7f040020

.field public static actionOverflowButtonStyle:I = 0x7f040021

.field public static actionOverflowMenuStyle:I = 0x7f040022

.field public static actionProviderClass:I = 0x7f040023

.field public static actionViewClass:I = 0x7f040025

.field public static activityChooserViewStyle:I = 0x7f040028

.field public static alertDialogButtonGroupStyle:I = 0x7f04002d

.field public static alertDialogCenterButtons:I = 0x7f04002e

.field public static alertDialogStyle:I = 0x7f04002f

.field public static alertDialogTheme:I = 0x7f040030

.field public static allowStacking:I = 0x7f040034

.field public static alphabeticModifiers:I = 0x7f040036

.field public static arrowHeadLength:I = 0x7f040041

.field public static arrowShaftLength:I = 0x7f040042

.field public static autoCompleteTextViewStyle:I = 0x7f040046

.field public static autoSizeMaxTextSize:I = 0x7f040048

.field public static autoSizeMinTextSize:I = 0x7f040049

.field public static autoSizePresetSizes:I = 0x7f04004a

.field public static autoSizeStepGranularity:I = 0x7f04004b

.field public static autoSizeTextType:I = 0x7f04004c

.field public static background:I = 0x7f04004f

.field public static backgroundSplit:I = 0x7f040056

.field public static backgroundStacked:I = 0x7f040057

.field public static backgroundTint:I = 0x7f040058

.field public static backgroundTintMode:I = 0x7f040059

.field public static barLength:I = 0x7f04006c

.field public static borderlessButtonStyle:I = 0x7f040083

.field public static buttonBarButtonStyle:I = 0x7f040096

.field public static buttonBarNegativeButtonStyle:I = 0x7f040097

.field public static buttonBarNeutralButtonStyle:I = 0x7f040098

.field public static buttonBarPositiveButtonStyle:I = 0x7f040099

.field public static buttonBarStyle:I = 0x7f04009a

.field public static buttonCompat:I = 0x7f04009b

.field public static buttonGravity:I = 0x7f04009c

.field public static buttonIconDimen:I = 0x7f04009e

.field public static buttonPanelSideLayout:I = 0x7f0400a1

.field public static buttonStyle:I = 0x7f0400a3

.field public static buttonStyleSmall:I = 0x7f0400a4

.field public static buttonTint:I = 0x7f0400a5

.field public static buttonTintMode:I = 0x7f0400a6

.field public static checkMarkCompat:I = 0x7f0400be

.field public static checkMarkTint:I = 0x7f0400bf

.field public static checkMarkTintMode:I = 0x7f0400c0

.field public static checkboxStyle:I = 0x7f0400c1

.field public static checkedTextViewStyle:I = 0x7f0400cc

.field public static closeIcon:I = 0x7f0400ef

.field public static closeItemLayout:I = 0x7f0400f6

.field public static collapseContentDescription:I = 0x7f0400f7

.field public static collapseIcon:I = 0x7f0400f8

.field public static color:I = 0x7f040106

.field public static colorAccent:I = 0x7f040107

.field public static colorBackgroundFloating:I = 0x7f040108

.field public static colorButtonNormal:I = 0x7f040109

.field public static colorControlActivated:I = 0x7f04010d

.field public static colorControlHighlight:I = 0x7f04010e

.field public static colorControlNormal:I = 0x7f04010f

.field public static colorError:I = 0x7f040110

.field public static colorPrimary:I = 0x7f04012a

.field public static colorPrimaryDark:I = 0x7f04012c

.field public static colorSwitchThumbNormal:I = 0x7f040141

.field public static commitIcon:I = 0x7f040146

.field public static contentDescription:I = 0x7f040162

.field public static contentInsetEnd:I = 0x7f040163

.field public static contentInsetEndWithActions:I = 0x7f040164

.field public static contentInsetLeft:I = 0x7f040165

.field public static contentInsetRight:I = 0x7f040166

.field public static contentInsetStart:I = 0x7f040167

.field public static contentInsetStartWithNavigation:I = 0x7f040168

.field public static controlBackground:I = 0x7f040174

.field public static customNavigationLayout:I = 0x7f040193

.field public static defaultQueryHint:I = 0x7f04019e

.field public static dialogCornerRadius:I = 0x7f0401a6

.field public static dialogPreferredPadding:I = 0x7f0401ab

.field public static dialogTheme:I = 0x7f0401ac

.field public static displayOptions:I = 0x7f0401af

.field public static divider:I = 0x7f0401b0

.field public static dividerHorizontal:I = 0x7f0401b2

.field public static dividerPadding:I = 0x7f0401b5

.field public static dividerVertical:I = 0x7f0401b7

.field public static drawableBottomCompat:I = 0x7f0401bf

.field public static drawableEndCompat:I = 0x7f0401c0

.field public static drawableLeftCompat:I = 0x7f0401c1

.field public static drawableRightCompat:I = 0x7f0401c2

.field public static drawableSize:I = 0x7f0401c3

.field public static drawableStartCompat:I = 0x7f0401c4

.field public static drawableTint:I = 0x7f0401c5

.field public static drawableTintMode:I = 0x7f0401c6

.field public static drawableTopCompat:I = 0x7f0401c7

.field public static drawerArrowStyle:I = 0x7f0401c8

.field public static dropDownListViewStyle:I = 0x7f0401cc

.field public static dropdownListPreferredItemHeight:I = 0x7f0401cd

.field public static editTextBackground:I = 0x7f0401d1

.field public static editTextColor:I = 0x7f0401d2

.field public static editTextStyle:I = 0x7f0401d4

.field public static elevation:I = 0x7f0401d5

.field public static emojiCompatEnabled:I = 0x7f0401d9

.field public static expandActivityOverflowButtonDrawable:I = 0x7f0401f6

.field public static firstBaselineToTopHeight:I = 0x7f04022a

.field public static fontFamily:I = 0x7f04025a

.field public static fontVariationSettings:I = 0x7f040264

.field public static gapBetweenBars:I = 0x7f04026b

.field public static goIcon:I = 0x7f04026d

.field public static height:I = 0x7f04027e

.field public static hideOnContentScroll:I = 0x7f040286

.field public static homeAsUpIndicator:I = 0x7f04028d

.field public static homeLayout:I = 0x7f04028e

.field public static icon:I = 0x7f040295

.field public static iconTint:I = 0x7f04029d

.field public static iconTintMode:I = 0x7f04029e

.field public static iconifiedByDefault:I = 0x7f04029f

.field public static imageButtonStyle:I = 0x7f0402a2

.field public static indeterminateProgressStyle:I = 0x7f0402aa

.field public static initialActivityCount:I = 0x7f0402b2

.field public static isLightTheme:I = 0x7f0402b6

.field public static itemPadding:I = 0x7f0402c7

.field public static lastBaselineToBottomHeight:I = 0x7f0402e7

.field public static layout:I = 0x7f0402e9

.field public static lineHeight:I = 0x7f040338

.field public static listChoiceBackgroundIndicator:I = 0x7f04033b

.field public static listChoiceIndicatorMultipleAnimated:I = 0x7f04033c

.field public static listChoiceIndicatorSingleAnimated:I = 0x7f04033d

.field public static listDividerAlertDialog:I = 0x7f04033e

.field public static listItemLayout:I = 0x7f040341

.field public static listLayout:I = 0x7f04034c

.field public static listMenuViewStyle:I = 0x7f04034d

.field public static listPopupWindowStyle:I = 0x7f04034e

.field public static listPreferredItemHeight:I = 0x7f04034f

.field public static listPreferredItemHeightLarge:I = 0x7f040350

.field public static listPreferredItemHeightSmall:I = 0x7f040351

.field public static listPreferredItemPaddingEnd:I = 0x7f040352

.field public static listPreferredItemPaddingLeft:I = 0x7f040353

.field public static listPreferredItemPaddingRight:I = 0x7f040354

.field public static listPreferredItemPaddingStart:I = 0x7f040355

.field public static logo:I = 0x7f040357

.field public static logoDescription:I = 0x7f040359

.field public static maxButtonHeight:I = 0x7f0403a0

.field public static measureWithLargestChild:I = 0x7f0403a9

.field public static menu:I = 0x7f0403aa

.field public static multiChoiceItemLayout:I = 0x7f04040f

.field public static navigationContentDescription:I = 0x7f040410

.field public static navigationIcon:I = 0x7f040411

.field public static navigationMode:I = 0x7f040413

.field public static numericModifiers:I = 0x7f04041d

.field public static overlapAnchor:I = 0x7f04042e

.field public static paddingBottomNoButtons:I = 0x7f040430

.field public static paddingEnd:I = 0x7f040432

.field public static paddingStart:I = 0x7f040435

.field public static paddingTopNoTitle:I = 0x7f040437

.field public static panelBackground:I = 0x7f040439

.field public static panelMenuListTheme:I = 0x7f04043a

.field public static panelMenuListWidth:I = 0x7f04043b

.field public static popupMenuStyle:I = 0x7f040451

.field public static popupTheme:I = 0x7f040452

.field public static popupWindowStyle:I = 0x7f040453

.field public static preserveIconSpacing:I = 0x7f040462

.field public static progressBarPadding:I = 0x7f040466

.field public static progressBarStyle:I = 0x7f040467

.field public static queryBackground:I = 0x7f04046b

.field public static queryHint:I = 0x7f04046c

.field public static radioButtonStyle:I = 0x7f04046e

.field public static ratingBarStyle:I = 0x7f040470

.field public static ratingBarStyleIndicator:I = 0x7f040471

.field public static ratingBarStyleSmall:I = 0x7f040472

.field public static searchHintIcon:I = 0x7f040488

.field public static searchIcon:I = 0x7f040489

.field public static searchViewStyle:I = 0x7f04048b

.field public static seekBarStyle:I = 0x7f040494

.field public static selectableItemBackground:I = 0x7f040496

.field public static selectableItemBackgroundBorderless:I = 0x7f040497

.field public static showAsAction:I = 0x7f0404b5

.field public static showDividers:I = 0x7f0404b7

.field public static showText:I = 0x7f0404bc

.field public static showTitle:I = 0x7f0404bd

.field public static singleChoiceItemLayout:I = 0x7f0404c5

.field public static spinBars:I = 0x7f0404d0

.field public static spinnerDropDownItemStyle:I = 0x7f0404d1

.field public static spinnerStyle:I = 0x7f0404d2

.field public static splitTrack:I = 0x7f0404d7

.field public static srcCompat:I = 0x7f0404dd

.field public static state_above_anchor:I = 0x7f0404ea

.field public static subMenuArrow:I = 0x7f0404fa

.field public static submitBackground:I = 0x7f040500

.field public static subtitle:I = 0x7f040501

.field public static subtitleTextAppearance:I = 0x7f040504

.field public static subtitleTextColor:I = 0x7f040505

.field public static subtitleTextStyle:I = 0x7f040506

.field public static suggestionRowLayout:I = 0x7f04050a

.field public static switchMinWidth:I = 0x7f04050f

.field public static switchPadding:I = 0x7f040510

.field public static switchStyle:I = 0x7f040513

.field public static switchTextAppearance:I = 0x7f040514

.field public static textAllCaps:I = 0x7f04053a

.field public static textAppearanceLargePopupMenu:I = 0x7f04055d

.field public static textAppearanceListItem:I = 0x7f04055f

.field public static textAppearanceListItemSecondary:I = 0x7f040560

.field public static textAppearanceListItemSmall:I = 0x7f040561

.field public static textAppearancePopupMenuHeader:I = 0x7f040563

.field public static textAppearanceSearchResultSubtitle:I = 0x7f040564

.field public static textAppearanceSearchResultTitle:I = 0x7f040565

.field public static textAppearanceSmallPopupMenu:I = 0x7f040566

.field public static textColorAlertDialogListItem:I = 0x7f040575

.field public static textColorSearchUrl:I = 0x7f040576

.field public static textLocale:I = 0x7f040581

.field public static theme:I = 0x7f04058b

.field public static thickness:I = 0x7f04058c

.field public static thumbTextPadding:I = 0x7f040597

.field public static thumbTint:I = 0x7f040598

.field public static thumbTintMode:I = 0x7f040599

.field public static tickMark:I = 0x7f04059f

.field public static tickMarkTint:I = 0x7f0405a0

.field public static tickMarkTintMode:I = 0x7f0405a1

.field public static tint:I = 0x7f0405a6

.field public static tintMode:I = 0x7f0405a7

.field public static title:I = 0x7f0405a9

.field public static titleMargin:I = 0x7f0405ad

.field public static titleMarginBottom:I = 0x7f0405ae

.field public static titleMarginEnd:I = 0x7f0405af

.field public static titleMarginStart:I = 0x7f0405b0

.field public static titleMarginTop:I = 0x7f0405b1

.field public static titleMargins:I = 0x7f0405b2

.field public static titleTextAppearance:I = 0x7f0405b5

.field public static titleTextColor:I = 0x7f0405b6

.field public static titleTextStyle:I = 0x7f0405b8

.field public static toolbarNavigationButtonStyle:I = 0x7f0405bd

.field public static toolbarStyle:I = 0x7f0405be

.field public static tooltipForegroundColor:I = 0x7f0405c0

.field public static tooltipFrameBackground:I = 0x7f0405c1

.field public static tooltipText:I = 0x7f0405c3

.field public static track:I = 0x7f0405c8

.field public static trackTint:I = 0x7f0405de

.field public static trackTintMode:I = 0x7f0405df

.field public static viewInflaterClass:I = 0x7f0405f3

.field public static voiceIcon:I = 0x7f0405f9

.field public static windowActionBar:I = 0x7f04060a

.field public static windowActionBarOverlay:I = 0x7f04060b

.field public static windowActionModeOverlay:I = 0x7f04060c

.field public static windowFixedHeightMajor:I = 0x7f04060d

.field public static windowFixedHeightMinor:I = 0x7f04060e

.field public static windowFixedWidthMajor:I = 0x7f04060f

.field public static windowFixedWidthMinor:I = 0x7f040610

.field public static windowMinWidthMajor:I = 0x7f040611

.field public static windowMinWidthMinor:I = 0x7f040612

.field public static windowNoTitle:I = 0x7f040613


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
