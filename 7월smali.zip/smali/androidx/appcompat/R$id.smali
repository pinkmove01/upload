.class public final Landroidx/appcompat/R$id;
.super Ljava/lang/Object;


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Landroidx/appcompat/R;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = "id"
.end annotation


# static fields
.field public static action_bar:I = 0x7f090034

.field public static action_bar_activity_content:I = 0x7f090035

.field public static action_bar_container:I = 0x7f090036

.field public static action_bar_root:I = 0x7f090037

.field public static action_bar_spinner:I = 0x7f090038

.field public static action_bar_subtitle:I = 0x7f090039

.field public static action_bar_title:I = 0x7f09003a

.field public static action_context_bar:I = 0x7f09003c

.field public static action_menu_divider:I = 0x7f090041

.field public static action_menu_presenter:I = 0x7f090042

.field public static action_mode_bar:I = 0x7f090043

.field public static action_mode_bar_stub:I = 0x7f090044

.field public static action_mode_close_button:I = 0x7f090045

.field public static activity_chooser_view_content:I = 0x7f090048

.field public static add:I = 0x7f090049

.field public static alertTitle:I = 0x7f09004f

.field public static buttonPanel:I = 0x7f090093

.field public static checkbox:I = 0x7f0900ab

.field public static checked:I = 0x7f0900ac

.field public static content:I = 0x7f0900c5

.field public static contentPanel:I = 0x7f0900c6

.field public static custom:I = 0x7f0900d4

.field public static customPanel:I = 0x7f0900d5

.field public static decor_content_parent:I = 0x7f0900e0

.field public static default_activity_button:I = 0x7f0900e1

.field public static edit_query:I = 0x7f090120

.field public static expand_activities_button:I = 0x7f09012c

.field public static expanded_menu:I = 0x7f09012d

.field public static group_divider:I = 0x7f090156

.field public static home:I = 0x7f090160

.field public static icon:I = 0x7f090167

.field public static image:I = 0x7f09016d

.field public static listMode:I = 0x7f09018c

.field public static list_item:I = 0x7f09018e

.field public static message:I = 0x7f0901b7

.field public static multiply:I = 0x7f0901dd

.field public static none:I = 0x7f0901f5

.field public static normal:I = 0x7f0901f6

.field public static off:I = 0x7f0901fb

.field public static on:I = 0x7f0901fd

.field public static parentPanel:I = 0x7f090232

.field public static progress_circular:I = 0x7f090270

.field public static progress_horizontal:I = 0x7f090271

.field public static radio:I = 0x7f090275

.field public static screen:I = 0x7f09028f

.field public static scrollIndicatorDown:I = 0x7f09029b

.field public static scrollIndicatorUp:I = 0x7f09029c

.field public static scrollView:I = 0x7f09029d

.field public static search_badge:I = 0x7f09029f

.field public static search_bar:I = 0x7f0902a0

.field public static search_button:I = 0x7f0902a1

.field public static search_close_btn:I = 0x7f0902a2

.field public static search_edit_frame:I = 0x7f0902a3

.field public static search_go_btn:I = 0x7f0902a4

.field public static search_mag_icon:I = 0x7f0902a5

.field public static search_plate:I = 0x7f0902a6

.field public static search_src_text:I = 0x7f0902a7

.field public static search_voice_btn:I = 0x7f0902a8

.field public static select_dialog_listview:I = 0x7f0902ba

.field public static shortcut:I = 0x7f0902cc

.field public static spacer:I = 0x7f0902e0

.field public static split_action_bar:I = 0x7f0902e8

.field public static src_atop:I = 0x7f0902ed

.field public static src_in:I = 0x7f0902ee

.field public static src_over:I = 0x7f0902ef

.field public static submenuarrow:I = 0x7f090322

.field public static submit_area:I = 0x7f090323

.field public static tabMode:I = 0x7f09032d

.field public static textSpacerNoButtons:I = 0x7f090349

.field public static textSpacerNoTitle:I = 0x7f09034a

.field public static title:I = 0x7f09035b

.field public static titleDividerNoCustom:I = 0x7f09035c

.field public static title_template:I = 0x7f09035e

.field public static topPanel:I = 0x7f090363

.field public static unchecked:I = 0x7f090374

.field public static uniform:I = 0x7f090375

.field public static up:I = 0x7f090377

.field public static wrap_content:I = 0x7f09039f


# direct methods
.method private constructor <init>()V
    .locals 0

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method
